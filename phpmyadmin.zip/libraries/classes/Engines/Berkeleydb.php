<?php
/**
 * The BerkeleyDB storage engine
 */

declare(strict_types=1);

namespace PhpMyAdmin\Engines;

/**
 * This is same as BDB
 */
class Berkeleydb extends Bdb
{
}
